# Unit 05O Stage 1 completion gates

**Locked before any unconstrained endpoint completed:** 2026-08-13  
**Parent protocol:** `UNIT05O_CLEAN_SLATE_QM_FORCE_MATCHING_PROTOCOL_LOCKED.md` (unchanged)

## Endpoint acceptance

Each of the four attempts retains its original terminal state. `CONVERGED_ENDPOINT` requires geomeTRIC convergence under the parent thresholds, converged final PBE-D3(BJ)/def2-SVP SCF, complete final coordinates/gradient, preserved 56-atom order/connectivity/protonation/stereochemistry, and no bond rearrangement. Failure, maximum-cycle termination, or invalid chemistry is archived and never silently replaced.

## Distinct-minimum clustering before Hessians

Only converged endpoints enter clustering. Heavy-atom RMSD is calculated after optimal heavy-atom alignment with canonical atom correspondence. Pairwise records also contain circular differences for φ=`56-26-10-9`, ψ=`26-10-9-8`, χ=`10-9-8-2`; S26-H56 and S26-C10 distances; and angles `9-10-26`, `11-10-26`, and `56-26-10`.

Two endpoints are the same candidate minimum only if all are true:

- heavy-atom RMSD ≤0.10 Å;
- each φ/ψ/χ circular difference ≤10°;
- each S-H/S-C difference ≤0.03 Å;
- each named angle difference ≤3°;
- electronic-energy difference ≤0.25 kcal/mol.

Clustering uses complete-linkage under this conjunction so every pair in a cluster satisfies every threshold. Borderline pairs are reported, not forcibly merged. One representative per cluster is the lowest-energy converged endpoint; all alternatives remain archived.

## Hessian/frequency gate

Run one analytic QM Hessian/frequency calculation at the identical frozen electronic level for every unique representative only after clustering completes. Preserve the Cartesian Hessian, mass-weighted eigenvalues/eigenvectors, frequencies, raw output, software versions, coordinates, convergence state, and checksums.

After projecting translation and rotation:

- `VERIFIED_LOCAL_MINIMUM`: no vibrational frequency below −20 cm⁻¹;
- `NOT_A_MINIMUM`: at least one frequency below −50 cm⁻¹ whose eigenvector is a chemically meaningful internal distortion;
- `NUMERICALLY_AMBIGUOUS`: any frequency from −50 to −20 cm⁻¹, or a frequency below −50 cm⁻¹ dominated by imperfect translation/rotation/numerical contamination and requiring review.

Modes between −20 and +20 cm⁻¹ are recorded as near-zero modes and inspected but do not alone reject a structure. Only `VERIFIED_LOCAL_MINIMUM` representatives may seed the snapshot cloud. No snapshot generation begins until all unique representatives have terminal frequency classifications.

## Required stop before Stage 2

After Hessian classification, stop again. Resolve and checksum the independent charge/vdW provenance decision before creating any snapshot coordinates. ForceBalance installation/fitting remains prohibited at this point.
